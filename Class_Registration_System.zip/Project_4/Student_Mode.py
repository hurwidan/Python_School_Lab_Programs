import Classes

# Load existing class data from file, or use the default class dictionary if not found
classes = Classes.load_classes() or Classes.classes

def enroll(student_name):
    print("\n")
    while True:
        class_name = input("Enter class name: ").strip().title()

        if class_name in classes:
            # Calculate available seats in the class
            available_seats = classes[class_name]["Maximum Capacity"] - len(classes[class_name]["Roster"])

            if available_seats > 0:
                # Check if the student is already enrolled
                if student_name not in classes[class_name]["Roster"]:
                    classes[class_name]["Roster"].append(student_name)
                    print("You have been successfully enrolled.\n")
                    Classes.save_classes()  # Save changes to file
                    break
                else:
                    print(f"You have already enrolled in {class_name}.\n")
                    break
            else:
                print("There are no available seats for this class.\n")
                break
        else:
            print("Class not found\n")
            break

def un_enroll(student_name):
    print("\n")
    while True:
        class_name = input("Enter class name: ").strip().title()

        if class_name in classes:
            # Check if the student is enrolled before attempting removal
            if student_name in classes[class_name]["Roster"]:
                classes[class_name]["Roster"].remove(student_name)
                print("You have been successfully un-enrolled.\n")
                Classes.save_classes()  # Save changes to file
                break
            else:
                print("You are not enrolled in this class.\n")
                break
        else:
            print("Class not found\n")

def print_schedule(student_name):
    print("\n")
    found = False
    schedule = []
    print(f"--- Schedule for {student_name} ---")

    for class_name, class_list in classes.items():
        # Ensure class_list is a list, otherwise convert it
        if isinstance(class_list, dict):
            class_list = [class_list]  # Convert single dictionary to list

        for details in class_list:
            if isinstance(details, dict) and student_name in details.get("Roster", []):
                schedule.append((details["Schedule"], class_name, details["Instructor"]))
                found = True

    if found:
        # Sort by schedule time, placing 'No schedule' last
        schedule.sort(key=lambda x: (x[0] == "No schedule", x[0]))
        for time, class_name, instructor in schedule:
            print(f"{class_name} - {instructor} ~ {time}")

    if not found:
        print(f"{student_name} is not enrolled in any classes.")

    print("\n")