import Classes

# Load existing class data from file, or use the default class dictionary if not found
classes = Classes.load_classes() or Classes.classes

def course_class():
    print("\n")
    while True:
        class_name = input("Enter class name: ").strip().title()

        # Check if class already exists
        if class_name in classes:
            update = input("Appears this class already exists. Would you like to update it? If not, it will be replaced. (yes/no): ").strip().lower()
            if update in ["yes", "y"]:
                while True:
                    # Prompt for updated class details
                    update_name = input("Enter new class name: ").strip().title()
                    update_instructor = input("Enter new class instructor: ").strip().title()
                    update_size = input("Enter new class size: ")
                    update_time = input("Enter new class time (24HR format): ").strip()

                    time_set = "No schedule"  # Default value if no time is provided

                    # Validate and process time input
                    if len(update_time) >= 4 and update_time.isdigit():
                        try:
                            hour = int(update_time[:2])
                            minutes = int(update_time[2:4])
                            if 0 <= hour <= 23 and 0 <= minutes <= 59:
                                time_set = f"{hour:02}:{minutes:02}"
                            else:
                                print("Invalid format. Hour must be 00-23, and minutes must be 00-59.")
                        except ValueError:
                            print("Invalid input. Please enter a numeric time in HHMM format.")
                    else:
                        print("Invalid input. Time must be exactly 4 digits (HHMM).")

                    try:
                        # Convert size input to integer
                        size = int(update_size)
                        existing_roster = classes[class_name]["Roster"]
                        del classes[class_name]  # Remove old entry

                        # Save updated class details
                        classes[update_name] = {
                            "Instructor": update_instructor,
                            "Roster": existing_roster,
                            "Maximum Capacity": size,
                            "Schedule": time_set
                        }
                        Classes.save_classes()
                        print(f"Class {class_name} renamed to {update_name} and updated successfully.\n")
                        break
                    except ValueError:
                        print("Invalid input. Class size must be a number. Try again.")
                return  # Exit function after update

        # If the class does not exist, create a new class
        instructor = input("Enter instructor: ").strip().title()
        class_size = input("Enter class size: ")

        while True:
            while True:
                update_time = input("Enter class time (24HR format): ").strip()
                if len(update_time) >= 4 and update_time.isdigit():
                    try:
                        hour = int(update_time[:2])
                        minutes = int(update_time[2:4])
                        if 0 <= hour <= 23 and 0 <= minutes <= 59:
                            time_set = f"{hour:02}:{minutes:02}"
                            break
                        else:
                            ValueError("Hour must be 00-23, and minutes must be 00-59.")
                    except ValueError:
                        print("Invalid input. Please enter a numeric time in HHMM format.")

                elif len(update_time) < 4:
                    print("Invalid input. Please enter a numeric time in HHMM format.")
                elif update_time == "":
                    time_set = "No schedule"
                    break

            try:
                size = int(class_size)
                # Add new class to the dictionary
                classes[class_name] = {"Instructor": instructor, "Roster": [], "Maximum Capacity": size, "Schedule": time_set}
                Classes.save_classes()  # Save to file
                print(f"Class {class_name} created successfully.\n")
                break
            except ValueError:
                print("Invalid input. Class size must be a number. Try again.")

def remove_class():
    print("\n")
    class_name = input("Enter the class name you'd like to remove: ").strip().title()

    if class_name in classes:
        del classes[class_name]
        Classes.save_classes()  # Save changes to file
        print(f"Removed {class_name} class successfully.\n")
    else:
        print("Class not found.\n")

def print_roster():
    print("\n")
    class_name = input("Enter the class name whose roster you'd like to see: ").strip().title()

    if class_name in classes:
        count = 0
        for class_name in classes:
            count += 1

        if count != 1:
            for class_name in classes:
                print(classes[class_name])
            print(f"It appears there are multiple classes for {class_name}.")
            instructor_select = input(f"Enter instructor of the desired {class_name} class: ").strip().title()
            roster = classes[class_name]["Instructor":instructor_select]["Roster"]
        else:
            roster = classes[class_name]["Roster"]

        if roster:
            print("\n")
            print(f"--- {class_name} Roster ({len(roster)} of {classes[class_name]['Maximum Capacity']}) ---\n")
            for count, student in enumerate(roster, 1):
                print(f'    - {student}')
    else:
        print("Class not found.")
    print("\n")
