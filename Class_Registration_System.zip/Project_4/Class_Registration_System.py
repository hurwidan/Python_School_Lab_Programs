import Administrator_Mode, Student_Mode

def main():
    while True:
        # Prompt user to select their role or exit the system
        mode = input("\nWelcome to the Class Registration System. Are you viewing as an 1) Administrator "
                     "or 2) Student? To exit, type 'exit' or 'e': ").strip().lower()
        print("\n")

        if mode == "1":  # Administrator Mode
            while True:
                # Administrator actions menu
                admin_choice = input(
                    "Would you like to: \n"
                    "  1) Add/Update Class\n"
                    "  2) Remove Class\n"
                    "  3) Print Class Roster\n"
                    "  4) Exit\n"
                    "Enter your choice: "
                ).strip().lower()

                if admin_choice == "1":
                    Administrator_Mode.course_class()  # Add or update a class
                elif admin_choice == "2":
                    Administrator_Mode.remove_class()  # Remove an existing class
                elif admin_choice == "3":
                    Administrator_Mode.print_roster()  # Print the roster for a class
                elif admin_choice == "4":
                    break  # Exit administrator mode
                else:
                    print("Invalid choice. Please try again.\n")

        elif mode == "2":  # Student Mode
            student_name = input("Enter student name: ").strip().title()

            if student_name != "":  # Ensure student name is not empty
                while True:
                    # Student actions menu
                    student_choice = input(
                        "Would you like to: \n"
                        "  1) Enroll in Classes\n"
                        "  2) Un-enroll from Classes\n"
                        "  3) Print Class Schedule\n"
                        "  4) Exit\n"
                        "Enter your choice: "
                    ).strip().lower()

                    if student_choice == "1":
                        Student_Mode.enroll(student_name)  # Enroll the student in a class
                    elif student_choice == "2":
                        Student_Mode.un_enroll(student_name)  # Remove the student from a class
                    elif student_choice == "3":
                        Student_Mode.print_schedule(student_name)  # Print the student's class schedule
                    elif student_choice == "4":
                        break  # Exit student mode
                    else:
                        print("Invalid choice. Please try again.\n")
            else:
                continue  # Restart if no name is provided

        elif mode == "exit" or mode == "e":
            break  # Exit the system
        else:
            print("Invalid choice. Please try again.\n")

main()