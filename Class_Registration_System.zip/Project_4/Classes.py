classes = {}

# Save the current class data to a file (classes.txt).
# Ensures data persistence across program runs.
def save_classes():
    global classes
    with open("classes.txt", "w") as file:
        if not classes:
            return  # Prevent writing empty braces if no data exists
        for class_name, details in classes.items():
            file.write(f"{class_name}:\n")
            file.write(f"  Instructor: {details.get('Instructor', 'No Instructor')}\n")
            file.write(f"  Maximum Capacity: {details['Maximum Capacity']}\n")
            file.write(f"  Roster: {', '.join(details['Roster']) if details['Roster'] else 'No students enrolled'}\n")
            file.write(f"  Schedule: {details.get('Schedule', 'No schedule')}\n\n")  # Ensure Schedule is retrieved correctly

# Load class data from the file (classes.txt) into the global dictionary.
# Ensures that class data is available when the program starts.
def load_classes():
    global classes
    try:
        with open("classes.txt", "r") as file:
            content = file.readlines()
            if not content or content == ["{}"]:
                return  # Prevent overwriting classes if file is empty or just {}
            temp_classes = {}
            class_name = None
            for line in content:
                line = line.strip()
                if line.endswith(":"):
                    # Create a new class entry
                    class_name = line[:-1]
                    temp_classes[class_name] = {
                        "Instructor": "No Instructor",
                        "Roster": [],
                        "Maximum Capacity": 0,
                        "Schedule": "No schedule"
                    }
                elif "Instructor:" in line:
                    # Extract instructor name
                    instructor_data = line.split(": ")[1]
                    temp_classes[class_name]["Instructor"] = instructor_data if instructor_data.strip() else "No Instructor"
                elif "Maximum Capacity:" in line:
                    # Extract class capacity
                    temp_classes[class_name]["Maximum Capacity"] = int(line.split(": ")[1])
                elif "Roster:" in line:
                    # Extract student roster, if any
                    roster_data = line.split(": ")[1]
                    temp_classes[class_name]["Roster"] = roster_data.split(", ") if roster_data != "No students enrolled" else []
                elif "Schedule:" in line:
                    # Extract class schedule
                    schedule_data = line.split(": ")[1]
                    temp_classes[class_name]["Schedule"] = schedule_data if schedule_data.strip() else "No schedule"
            if temp_classes:  # Only update if file has valid data
                classes.update(temp_classes)
    except FileNotFoundError:
        # Create an empty file if it does not exist
        with open("classes.txt", "w"):
            pass

# Load classes when the script runs
load_classes()
